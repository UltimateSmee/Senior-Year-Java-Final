package GROUP;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ConnectionHandler extends Thread {
	private static ServerSocket socket;
	public static ArrayList<DataOutputStream> out = new ArrayList<DataOutputStream>();
	public static ArrayList<DataInputStream> in = new ArrayList<DataInputStream>();
	private static Socket connection;
	private static int groupSize;

	public ConnectionHandler(ServerSocket sockett, int groupSizee) {
		socket = sockett;
		groupSize = groupSizee;
	}

	@Override
	public void run() {
		try {
			for (int i = 0; i < groupSize; i++) {	
				connection = socket.accept();
				out.add(new DataOutputStream(connection.getOutputStream()));
				in.add(new DataInputStream(connection.getInputStream()));
				/*
				Socket connectsocket = socket.accept();
				connections[i] = connectsocket;
				OutputStream out2Temp = connectsocket.getOutputStream();
				outToUser[i] = out2Temp;
				DataOutputStream outTemp = new DataOutputStream(out2Temp);
				out[i] = outTemp;
				InputStream in2Temp = connectsocket.getInputStream();
				inToServer[i] = in2Temp;
				DataInputStream inTemp = new DataInputStream(in2Temp);
				in[i] = inTemp;
				*/
				Server.setOut(out);
				Server.setIn(in);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void remove(int userNameIndex) {
		in.remove(userNameIndex);
		out.remove(userNameIndex);
		Server.setOut(out);
		Server.setIn(in);
	}
	
	public static ArrayList<DataInputStream> getIn() {
		return in;
	}

	public static ArrayList<DataOutputStream> getOut() {
		return out;
	}
}
