package GROUP;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {

	private static Scanner scan;
	private static int port;
	public static String CURRENT_GROUP;
	private static boolean on = true;
	private static Socket socket;
	private static Thread retrieve;
	private static DataOutputStream out;
	private static DataInputStream in;
	private static String userName;

	public Client(String CURRENT_GROUP, int port, String userName) {
		scan = new Scanner(System.in);
		Client.CURRENT_GROUP = CURRENT_GROUP;
		Client.port = port;
		Client.userName = userName;
		joinServer();
		on = true;
	}

	public void joinServer() {
		try {
			socket = new Socket("", port);
			out = new DataOutputStream(socket.getOutputStream());
			in = new DataInputStream(socket.getInputStream());
			System.out.println("\nWelcome to the group " + userName + "!");
			retrieve = new Thread() {
				public void run() {
					while (on) {
						try {
							if (in.available() > 3) {
								String message = in.readUTF();
								System.out.println(message);
							}
						} catch (IOException ioe2) {
							ioe2.printStackTrace();
						}
					}
				}
			};
			retrieve.start();
			while (on) {
				System.out.print("\nEnter: ");
				String message = scan.nextLine();
				if (message.startsWith("\\")) {
					// I get a syntax error with only two \'s
					checkCommand(message.replaceFirst("\\\\", "").toLowerCase());
				} else {
					out.writeUTF(userName + " - " + message);
					out.flush();
				}
			}
		} catch (IOException ioe) {
			System.out.println("Couldn't Connect");
		}
	}

	public void checkCommand(String command) {
		if (command.equals("help")) {
			System.out.println("You are not the host you can only quit" + "\nwith '\\quit' or '\\q'.");
		} else if (command.equals("quit") || command.equals("q")) {
			try {
				out.writeUTF(userName + "-leaving13av1n6");
				out.flush();
				on = false;
				socket.close();
				retrieve.join();
				Thread.sleep(50);
				out.close();
				in.close();
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
			Start.restart();
		}
	}
}
