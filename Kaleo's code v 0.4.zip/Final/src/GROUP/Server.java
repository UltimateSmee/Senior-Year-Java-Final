package GROUP;
//This Class just creates a server for clients to join

import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class Server extends Thread {

	private static ServerSocket socket;
	private static ArrayList<DataOutputStream> out;
	private static ArrayList<DataInputStream> in;
	private static Thread conH;
	private static String message;
	private static ArrayList<String> userNames = new ArrayList<String>();
	private static String lastUser;
	private static boolean on;

	public Server(int port, int groupSize, boolean host, String userName) throws IOException {
		socket = new ServerSocket(port);
		conH = new ConnectionHandler(socket, groupSize);
		conH.start();
		begin(host, userName);
		on = true;
	}

	public void begin(boolean host, String userName) {
		Scanner scan = new Scanner(System.in);
		System.out.println("You are now the host." + "\nYou can use commands by pressing '\\' and typing the command.");
		Thread t = new Thread("Server Send") {
			public void run() {
				while (on) {
					try {
						if (in != null) {
							// A Unicode character can be between 1 and bytes
							for (int i = 0; i < in.size(); i++) {
								if (in.get(i).available() > 4) {

									String message = in.get(i).readUTF();
									lastUser = message.replaceAll(" ", "").split("-")[0];
									if (!userNames.contains(lastUser))
										userNames.add(lastUser);

									if (message.contains("leaving13av1n6")) {
										System.out.println("Removing " + lastUser + " from the group.");
										int indexToRemove = userNames.indexOf(lastUser);
										ConnectionHandler.remove(indexToRemove);
									} else {
										System.out.println(message);
										for (int p = 0; p < out.size(); p++) {
											if (p != i) {
												out.get(p).writeUTF(message);
												out.get(p).flush();
											}
										}
									}
								}
							}
						} else
							System.out.print("");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		};
		t.start();
		if (host) {
			while (on) {
				System.out.print("\nEnter: ");
				message = scan.nextLine();
				if (message.startsWith("\\")) {
					// I get a syntax error with only two \'s
					//checkCommand(message.replaceFirst("\\\\", "").toLowerCase());
				} else if (in != null) {
					for (int p = 0; p < out.size(); p++) {
						try {
							out.get(p).writeUTF(userName + " - " + message);
							out.get(p).flush();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
	}
	
	// TODO if the quit option is checked, change host.
	
	/*
	public void checkCommand(String command) {
		if (command.equals("help")) {
			System.out.println("You are not the host you can only quit" + "\nwith '\\quit' or '\\q'.");
		} else if (command.equals("quit") || command.equals("q")) {
			try {
				out.writeUTF(userName + "-leaving13av1n6");
				out.flush();
				on = false;
				socket.close();
				retrieve.join();
				Thread.sleep(50);
				out.close();
				in.close();
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
			Start.restart();
		}
	}
	*/
	public static void setOut(ArrayList<DataOutputStream> newOut) {
		out = newOut;
	}

	public static ArrayList<DataOutputStream> getOut() {
		return ConnectionHandler.getOut();
	}

	public static void setIn(ArrayList<DataInputStream> newIn) {
		in = newIn;
	}

	public static ArrayList<DataInputStream> getIn() {
		return ConnectionHandler.getIn();
	}
}
