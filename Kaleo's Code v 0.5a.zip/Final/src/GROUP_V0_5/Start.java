package GROUP_V0_5;

/*	Group Message V 0.4
 * 
 * --- Do not user Start. Use MessageFrame for everything after V 0.5 ---
 * 
 * 
 * 
 * Checklist is as follows:
 * 	1. Groups with names √
 * 	2. User names √
 * 	3. ALLOW MULTIPLE CONNECIONS √
 * 	4. Leave / join without exiting the app (Client only) √
 * 	5. Host Migration --
 * 	6. Move to a GUI
 * 	7. Make it pretty
 * 	8. Add settings button
 * 	9. Allow manual group size
 * 	10. Sent and read confirmation
 * 	11. Different way to send data about the client
 * 	18. Notifications??
 * 	19. Multiple groups at a time????
 * 	20. Encryption????????????
 */
import java.util.Scanner;

public class Start {

	private static String[] Alpha = { "", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
			"p", "q", "u", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "4", "5", "6", "7", "8", "9",
			"_" };

	private static int port;
	private static String GROUP_NAME;
	private static String GROUP_SIZE = "10";

	private static Scanner scan;
	private static String userName;

	public static void main(String[] args) {
		scan = new Scanner(System.in);
		port = 5;

		System.out.print("Only A-Z, a-z, 0-9, and '_' will be accepted." + "\nOther characters will be deleted."
				+ "\nGroup Name: ");
		GROUP_NAME = scan.nextLine();

		System.out.print("\nUsername: ");
		userName = scan.nextLine();

		Server.main(new String[] { getPort(GROUP_NAME), GROUP_SIZE, userName, GROUP_NAME });
	}

	public static String getPort(String GROUP_NAME) {
		for (int i = 0; i < GROUP_NAME.length(); i++) {
			for (int p = 1; p < 38; p++) {
				if (Alpha[p].equals(GROUP_NAME.substring(i, i + 1).toLowerCase()))
					port += Math.abs((p - (4 * p)) * (p + p));
				// else
				// Start.GROUP_NAME = GROUP_NAME.replace(GROUP_NAME.substring(i,
				// i+1), "");
				if (port >= 65540)
					port -= p * p * p;
			}
		}
		return ("" + port);
	}
}
