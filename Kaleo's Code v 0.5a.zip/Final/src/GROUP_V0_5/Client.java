package GROUP_V0_5;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client extends Thread {

	private static Scanner scan;
	private static int port;
	private static boolean on = true;
	private static Socket socket;
	private static Thread retrieve;
	private static DataOutputStream out;
	private static DataInputStream in;
	private static String userName;

	public Client(int port, String userName) throws Exception{
		Client.port = port;
		Client.userName = userName;
		on = true;
		socket = new Socket("", port);
		joinServer();
	}

	public static void main(String[] args) throws Exception {
		port = Integer.parseInt(args[0]);
		userName = args[1];
		new Client(port, userName);
	}

	public void joinServer() throws IOException {
		scan = new Scanner(System.in);
		out = new DataOutputStream(socket.getOutputStream());
		in = new DataInputStream(socket.getInputStream());
		System.out.println("\nWelcome to the group " + userName + "!");
		out.writeUTF(userName + "-newN3W22");
		out.flush();
		
		// this thread runs in the background to pick up any message even while
		// you are typing.
		retrieve = new Thread() {
			public void run() {
				while (on) {
					try {
						if (in.available() > 3) {

							String message = in.readUTF();

							if (message.split("-").length == 10) {
								exitGroup();
								try {
									Thread.sleep(1000);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								Server.main(new String[] {message.split("-")[0], message.split("-")[1], userName} );
								socket.close();
								
							} else if (message.split("-").length == 11) {
								exitGroup();
								try {
									Thread.sleep(250);
									Client.main(new String[] {message.split("-")[0], userName} );
									socket.close();
								} catch (Exception e) {
									e.printStackTrace();
								}

							} else {
								System.out.println(message);

							}
						}
					} catch (IOException ioe2) {
						ioe2.printStackTrace();

					}
				}
			}
		};
		retrieve.start();

		// this while loop just lets you type forever essentially
		while (on) {
			System.out.print("\nEnter: ");
			String message = scan.nextLine();
			if (message.startsWith("\\")) {
				// I get a syntax error with only two \'s
				checkCommand(message.replaceFirst("\\\\", "").toLowerCase());
			} else {
				try {
				out.writeUTF(userName + " - " + message);
				out.flush();
				} catch (IOException e) {
					on = false;
				}
			}
		}
	}

	// TODO add more commands for the client
	public void checkCommand(String command) {
		if (command.equals("help")) {
			System.out.println("You are not the host you can only quit" + "\nwith '\\quit' or '\\q'.");
		} else if (command.equals("quit") || command.equals("q")) {
			exitGroup();
			try {
				this.interrupt();
				this.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Start.main(null);
		}
	}

	private void exitGroup() {
		try {
			on = false;
			out.writeUTF(userName + "-leaving13av1n6");
			out.flush();
			
			socket.close();
			this.join();
			out.close();
			in.close();
		} catch (IOException | InterruptedException e) {
			//e.printStackTrace();
			try {
				socket.close();
				this.join();
			} catch (IOException | InterruptedException e1) {
				//e1.printStackTrace();
			}
			
		}
	}
}
