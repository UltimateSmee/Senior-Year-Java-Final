package GROUP_V0_5;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ConnectionHandler extends Thread {
	private static ServerSocket socket;
	private static Socket connection;

	public static ArrayList<DataOutputStream> out = new ArrayList<DataOutputStream>();
	public static ArrayList<DataInputStream> in = new ArrayList<DataInputStream>();
	private static ArrayList<String> userNames = new ArrayList<String>();

	private static int groupSize;
	public static boolean on;

	public ConnectionHandler(ServerSocket sockett, int groupSizee) {
		socket = sockett;
		groupSize = groupSizee;
		on = false;
		System.out.println(this.getId());
	}

	@Override
	public void run() {
		System.out.println("Started the connection handler");
		for (int i = 0; i < groupSize; i++) {
			try {
				System.out.println("waiting");
				connection = socket.accept();

				out.add(new DataOutputStream(connection.getOutputStream()));
				in.add(new DataInputStream(connection.getInputStream()));
				System.out.println("got someone - " + in.get(in.size() - 1));

				Server.setOut(out);
				Server.setIn(in);
				if (on) {

					break;
				}
			} catch (Exception e) {
				e.printStackTrace();
				break;
			}
		}
	}

	// This remove method is for normally removing a user by their user name.
	public static void removeUser(String user) {
		int numb = userNames.indexOf(user);
		in.remove(numb);
		out.remove(numb);
		userNames.remove(numb);
		Server.setOut(out);
		Server.setIn(in);
	}

	// This remove method is for removing a user by their Output stream if there
	// happens to be an error
	public static void removeUser(DataOutputStream user) {
		int numb = in.indexOf(user);
		in.remove(numb);
		out.remove(numb);
		Server.setOut(out);
		Server.setIn(in);
	}

	public static ArrayList<DataInputStream> getIn() {
		return in;
	}

	public static ArrayList<DataOutputStream> getOut() {
		return out;
	}

	public static void addUser(String user) {
		if (!userNames.contains(user))
			userNames.add(user);
	}

	public static ArrayList<String> getUserList() {
		return userNames;
	}

	public static void setGroupSize(int size) {
		groupSize = size;
	}
}
