package GROUP_V0_5;
//This Class just creates a server for clients to join

import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class Server extends Thread {

	private static ServerSocket socket;
	private ArrayList<DataOutputStream> out;
	private ArrayList<DataInputStream> in;
	private static ArrayList<DataOutputStream> outTemp;
	private static ArrayList<DataInputStream> inTemp;
	private static ArrayList<String> currentUsers;

	private static String lastUser;
	private static String userName;
	private boolean on;
	private static int port;
	private static int groupSize;
	private static String groupName;
	private static String message;
	private static Scanner scan;

	private Thread t;
	private Thread conH;

	public Server(int port, int groupSize) {
		scan = new Scanner(System.in);
		boolean cont = true;
		try {
			socket = new ServerSocket(port);
		} catch (IOException e) {
			cont = false;
			System.out.println(
					"Uh oh. It looks like that group was already made." + "\nDo you want to join that group? (y/n)");
			String c = scan.next();

			if (c.toLowerCase().equals("y")) {
				try {
					Client.main(new String[] { ("" + port), userName });
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			} else {
				Start.main(null);
				cont = false;
			}
		}
		if (cont) {
			conH = new ConnectionHandler(socket, groupSize);
			conH.start();
			on = true;
			begin();
		}
	}

	public static void main(String[] args) {
		port = Integer.parseInt(args[0]);
		groupSize = Integer.parseInt(args[1]);
		userName = args[2];
		groupName = args[3];
		new Server(port, groupSize);
	}

	public void begin() {
		System.out.println("You are now the host." + "\nYou can use commands by pressing '\\' and typing the command.");
		t = new Thread("Server Send") {
			public void run() {
				while (on) {
					try {
						in = inTemp;
						out = outTemp;
						if (in != null) {
							// A Unicode character can be between 1 and 4 bytes
							for (int i = 0; i < in.size(); i++) {
								if (in.get(i) != null && in.get(i).available() > 4) {

									String message = in.get(i).readUTF();

									if (message.contains("newN3W22")) {
										lastUser = message.split("-")[0];
										ConnectionHandler.addUser(lastUser);

									} else if (message.contains("leaving13av1n6")) {
										System.out.println("Removing " + lastUser + " from the group.");
										ConnectionHandler.removeUser(lastUser);

									} else {
										System.out.println(message);
										for (int p = 0; p < out.size(); p++) {
											if (p != i) {
												out.get(p).writeUTF(message);
												out.get(p).flush();

											}
										}
									}
								}
							}
						} else {
							System.out.print("");
						}
					} catch (IOException e) {
						// For some reason the loop doesn't stop even though I
						// turned on to false
						// maybe adding a break here will help?
						break;

					}
				}
			}
		};
		t.start();
		while (on) {
			System.out.print("\nEnter: ");
			message = scan.nextLine();

			if (message.startsWith("\\")) {
				// I get a syntax error with only two \'s
				checkCommand(message.replaceFirst("\\\\", "").toLowerCase());

			} else if (in != null) {
				for (int p = 0; p < out.size(); p++) {
					try {
						out.get(p).writeUTF(userName + " - " + message);
						out.get(p).flush();

					} catch (IOException e) {
						// e.printStackTrace();
						System.out.println("Tried and failed(SOCKET EXECPTION ON THAT STREAM) to out to " + in.get(p)
								+ "\nAttempting to remove that stream...");
						ConnectionHandler.removeUser(out.get(p));
						// on = false;

					}
				}
			}
		}
	}

	public void checkCommand(String command) {
		if (command.equals("help")) {
			System.out.println("The Available Commands Are: " + "\n \\quit or \\q" + "\n \\getPort" + "\n \\getUsers"
					+ "\n \\setGroupSize" + "\n \\getGroupSize");

		} else if (command.equals("quit") || command.equals("q")) {
			System.out.println("Exiting");
			exitGroup();
			Start.main(null);
			try {
				this.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		} else if (command.equals("getport")) {
			System.out.println("Port: " + socket.getLocalPort());
		} else if (command.equals("getgroup")) {
			System.out.println("Group: " + groupName);
		} else if (command.equals("getusers")) {
			currentUsers = ConnectionHandler.getUserList();
			System.out.println("Current Number Of Users: " + currentUsers.size());
			if (currentUsers.size() == 0) {
				System.out.println("	No Current Users");
			} else {
				System.out.println("	Users:");
				for (int i = 0; i < currentUsers.size(); i++) {
					System.out.println("	   " + currentUsers.get(i));
				}
			}
		} else if (command.equals("setgroupsize")) {
			System.out.print("\n	Enter the size: ");
			int newSize = scan.nextInt();
			ConnectionHandler.setGroupSize(newSize);
			groupSize = newSize;
			System.out.println("	GroupSize --> " + groupSize);
		} else if (command.equals("getgroupsize")) {
			System.out.println("GroupSize --> " + groupSize);
		}
		// TODO add more commands and add a moderator option for later
		// in ver 0.6 or something
	}

	private void exitGroup() {
		try {
			on = false;
			t.join();
			ConnectionHandler.on = true;

			Socket socketq = new Socket("", port);
			ConnectionHandler.addUser("tEmPUsERDon0tUseTHiSName");
			Server.sleep(50);

			socketq.close();
			ConnectionHandler.removeUser("tEmPUsERDon0tUseTHiSName");

			conH.join();
			socket.close();
			this.join();
			if (out != null && out.size() > 0) {
				out.get(0).writeUTF(port + "-" + groupSize + "- - - - - - - - ");
				out.get(0).flush();
				for (int p = 1; p < out.size(); p++) {
					out.get(p).writeUTF(port + "- - - - - - - - - - ");
					out.get(p).flush();
				}

				for (int p = 0; p < out.size(); p++) {
					out.get(p).close();
					in.get(p).close();
				}
			}
		} catch (IOException | InterruptedException e) {
			// e.printStackTrace();
			try {
				socket.close();
				this.join();
			} catch (IOException | InterruptedException e1) {
				// e1.printStackTrace();
			}
		}
	}

	public static void setOut(ArrayList<DataOutputStream> newOut) {
		outTemp = newOut;
	}

	public ArrayList<DataOutputStream> getOut() {
		return this.getOut();
	}

	public static void setIn(ArrayList<DataInputStream> newIn) {
		inTemp = newIn;
	}

	public ArrayList<DataInputStream> getIn() {
		return this.getIn();
	}

}
