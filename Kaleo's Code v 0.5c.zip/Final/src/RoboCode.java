import java.awt.Color;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class RoboCode {
	private JFrame frame = new JFrame();
	private JPanel panel = new JPanel();
	public int width = 800;
	public int height = 400;
	
	public RoboCode() {
		roboStart();
	}
	
	public static void main(String[] args) {
		RoboCode rc = new RoboCode();
	}
	
	public void roboStart() {
		frame.setSize(width, height);
		frame.add(panel);
		panel.setBackground(Color.black);
		frame.show();
	}
}
