
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;

import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Point;


public class begin {
	private static Frame frame;
	private Canvas c;
	private Canvas up;
	private Color color;
	private int r,g,b,a;
	public static Point mousepoint;
	private Graphics graphics;
	private Graphics graphicsnote;
	private Graphics upgraphics;
	public int width = 16*70;
	public int height = 9*70;
	public BufferStrategy strategy;
	private JLabel note;
	public JButton button;
	public boolean go;
	public String SHAPE = "1";
	
	public begin() {
		createCanvas();
	}
	
	public static void main(String[] args) {
		begin b = new begin();
		b.render();
	}
	
	public void createCanvas() {
		r = 100;
		g = 100;
		b = 100;
		frame = new Frame("Test");
		frame.setLayout(null);
		up = new Canvas();
		 c = new Canvas();
		 note = new JLabel("fafdfwaea");
		frame.add(c);
		frame.add(note);
		up.setBackground(new Color(200,255,200,100));
		/*
		button = new JButton("Button");
		button.setBackground(Color.pink);
		button.setBounds(0,50, 100, 50);
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("DS");
				
			}
		});
		frame.add(button);
		*/
		frame.setSize(width, height);
		c.setBounds(100, 100,frame.getWidth(), frame.getHeight()-50);
		note.setBounds(100, 0, frame.getWidth(), frame.getHeight()-50);
		note.setLocation(100, 0);
		frame.setResizable(true);
		c.setBackground(new Color(r, g, b));
		MouseWatcher MW = new MouseWatcher(this);
		KeyWatcher KW = new KeyWatcher(this);
		c.addMouseListener(MW);
		c.addKeyListener(KW);
		c.addMouseMotionListener(MW);
		up.addMouseListener(MW);
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent windowEvent) {
				System.exit(0);
			}
		});
	}
	
	public void render() {
		frame.setVisible(true);
		//render();
		//addStuff();
	}
	
	public void updatePoint() {
		note.setVisible(true);
		note.setText("TheMouseCords " + mousepoint);
		System.out.println("TheMouseCords " + mousepoint);
	}
	
	public void fade(int which) {
		while (!(r + g + b >= 765) && !(r + g + b <= 0)) {
			if (which == 1) {
				if (r < 255) {
					r++;
				}
				if (g < 255) {
					g++;
				}
				if (b < 255) {
					b++;
				}
			} else if (which == 0){
				if (r > 0) {
					r--;
				}
				if (g > 0) {
					g--;
				}
				if (b > 0) {
					b--;
				}
			}
			color = new Color(r, g, b);
			c.setBackground(color);
			c.repaint();
			System.out.println(c.getBackground().getRed() + c.getBackground().getGreen() + c.getBackground().getBlue());
			try {
				Thread.sleep(10);
			} catch (InterruptedException ie) {
				ie.printStackTrace();
			}
		}
		if (r + g +b == 765) {
			r--;
			g--;
			b--;
		} else {
			r++;
			g++;
			b++;
		}
	}
	
	public void addStuff() {
		graphics = c.getGraphics();
		if (SHAPE ==  "1") {
			graphics.fillOval((int)mousepoint.getX(), (int)mousepoint.getY(), 25, 25);
		} else if (SHAPE == "2") {
			graphics.fillRect((int)mousepoint.getX(), (int)mousepoint.getY(), 25, 25);
		}
		updatePoint();
	}
	
	public void dragStuff() {
		upgraphics = up.getGraphics();
		upgraphics.drawRect((int)mousepoint.getX(), (int)mousepoint.getY(), 10,10);
	}
	public boolean mouseClicked(MouseEvent e) {
		mousepoint = e.getPoint();
		addStuff();
		System.out.println("Mouse Clicked!");
		go = true;
		return true;
	}
	
	public boolean mouseReleased(MouseEvent e) {
		System.out.println("Mouse Released!");
		mousepoint = e.getPoint();
		go = true;
		return true;
	}
	
	public void mouseDragged(MouseEvent e, boolean go) {
		addStuff();
		System.out.println("Mouse Dragged!");
		graphicsnote = note.getGraphics();
		mousepoint = e.getPoint();
	}
	
	public void mouseMoved(MouseEvent e) {
		graphicsnote = note.getGraphics();
		mousepoint = e.getPoint();
		System.out.println("Mouse Moved!");
	}
	 
	public void keyPressed(KeyEvent e) {
		note.repaint();
		SHAPE = KeyEvent.getKeyText(e.getKeyCode());
		System.out.println(KeyEvent.getKeyText(e.getKeyCode()));
	}
	
	public void keyReleased(KeyEvent e) {
		graphicsnote.drawString(KeyEvent.getKeyText(e.getKeyCode()), 10, 15);
		if (e.getKeyCode() == 67 || e.getKeyCode() == 99) {
			c.repaint();
		}
	}
	class MouseWatcher extends MouseAdapter {
		
		private begin begin;
		
		public MouseWatcher(begin begin) {
			this.begin = begin;
		}
		
		public void mouseClicked(MouseEvent e) {
			begin.mouseClicked(e);
		}
		
		public void mouseReleased(MouseEvent e) {
			begin.mouseReleased(e);
		}
		
		public void mouseMoved(MouseEvent e) {
			begin.mouseMoved(e);
		}
		
		public void mouseDragged(MouseEvent e) {
			begin.mouseDragged(e, go);
		}
	}
}

	class KeyWatcher extends KeyAdapter {
		
		private begin begin;
		
		public KeyWatcher(begin begin) {
			this.begin = begin;
		}
		
		public void keyPressed(KeyEvent e) {
			begin.keyPressed(e);
		}
		
		public void keyReleased(KeyEvent e) {
			begin.keyReleased(e);
		}
	}