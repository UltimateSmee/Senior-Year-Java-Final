import java.awt.Canvas;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class asd {
	
	private int width = 16*40;
	private int height = 9*40;
	private Label keynote = new Label();
	private Label mousenote = new Label();
	private JFrame frame = new JFrame("Test");
	private JPanel panel = new JPanel();
	
	public static void main(String[] args) {
		asd asd = new asd();
		asd.init();
	}
	
	public void init() {
		frame.setSize(width, height);
		frame.add(panel);
		MouseWatcher MW = new MouseWatcher(this);
		KeyWatcher KW = new KeyWatcher(this);
		frame.addKeyListener(KW);
		keynote.addMouseListener(MW);
		keynote.addMouseMotionListener(MW);
		mousenote.addMouseListener(MW);
		mousenote.addMouseMotionListener(MW);
		frame.setBackground(Color.BLACK);
		panel.setLayout(new GridLayout(1, 2));
		panel.setBounds(0, 0, width, height);
		keynote.setBackground(Color.pink);
		mousenote.setBackground(Color.blue);
		panel.add(keynote);
		panel.add(mousenote);
		keynote.setAlignment(Label.CENTER);
		mousenote.setAlignment(Label.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
	
	public void mouseMoved(MouseEvent e) {
		System.out.println("Mouse Moved");
		mousenote.setText("Mouse Moved" + "\n " + e.getPoint());
	}
	
	public void mouseDragged(MouseEvent e) {
		System.out.println("Mouse Dragged");
		mousenote.setText("Mouse Dragged" + "\n " + e.getPoint());
	}
	
	public void mouseClicked(MouseEvent e) {
		System.out.println("Mouse Clicked");
		mousenote.setText("Mouse Clicked" + "\n " + e.getPoint());
	}
	
	public void mouseReleased(MouseEvent e) {
		System.out.println("Mouse Released");
		mousenote.setText("Mouse Released" + "\n " + e.getPoint());
	}
	
	public void keyPressed(KeyEvent e) {
		System.out.println("Key Pressed " + KeyEvent.getKeyText(e.getKeyCode()));
		keynote.setText("Last Key Pressed " + KeyEvent.getKeyText(e.getKeyCode()));
	}
	
	public void keyReleased(KeyEvent e) {
		
	}
	
	class MouseWatcher extends MouseAdapter {
	
		private asd asd;
		
		public MouseWatcher(asd asd) {
			this.asd = asd;
		}
		
		public void mouseMoved(MouseEvent e) {
			asd.mouseMoved(e);
		}
		
		public void mouseDragged(MouseEvent e) {
			asd.mouseDragged(e);
		}
		
		public void mouseClicked(MouseEvent e) {
			asd.mouseClicked(e);
		}
		
		public void mouseReleased(MouseEvent e) {
			asd.mouseReleased(e);
		}
	}
	
	class KeyWatcher extends KeyAdapter {
		
		private asd asd;
		
		public KeyWatcher(asd asd) {
			this.asd = asd;
		}
		
		public void keyPressed(KeyEvent e) {
			asd.keyPressed(e);
		}
		
		public void keyReleased(KeyEvent e) {
			asd.keyReleased(e);
		}
	}
}