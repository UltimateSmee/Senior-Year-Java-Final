package GROUP_V0_5;

public class logger {

	// I was thinking that I use this as a cleaner way to use the loggers in the
	// server and client classes
	// rather than just copying it into both of them and making it a very dirty.
}
