package GROUP;
//This Class just creates a server for clients to join

import java.net.*;
import java.util.ArrayList;
import java.io.*;

public class Server extends Thread {

	private static ServerSocket socket;
	private static ArrayList<DataOutputStream> out;
	private static ArrayList<DataInputStream> in;
	private static Thread conH;

	public Server(int port, int groupSize) throws IOException {
		socket = new ServerSocket(port);
		conH = new ConnectionHandler(socket, groupSize);
		conH.start();
	}

	public void run() {
		while (true) {
			try {
				Server.sleep(50);
				//Socket connectsocket = socket.accept();
				for (int i = 0; i < in.size(); i++) {
					if (in.get(i) != null && in.get(i).available() > 1) {
						for (int p = 0; p < out.size(); p++) {
							out.get(p).writeUTF(in.get(i).readUTF());
							out.get(p).flush();
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException ie) {
				ie.printStackTrace();
			}
		}
	}
	public static void setOut(ArrayList<DataOutputStream> newOut) {
		out = newOut;
	}
	
	public static ArrayList<DataOutputStream> getOut() {
		return ConnectionHandler.getOut();
	}
	
	public static void setIn(ArrayList<DataInputStream> newIn) {
		in = newIn;
	}
	
	public static ArrayList<DataInputStream> getIn() {
		return ConnectionHandler.getIn();
	}
}
