package GROUP;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {

	private static String userName;
	private static String message;
	private static Scanner scan;
	private static int port;
	public static String CURRENT_GROUP;

	public Client(String CURRENT_GROUP, int port) {
		scan = new Scanner(System.in);
		Client.CURRENT_GROUP = CURRENT_GROUP;
		Client.port = port;
	}

	public void joinServer() {
		try {
			Socket socket = new Socket("", port);
			System.out.print("Username: ");
			userName = scan.next();
			DataOutputStream out = new DataOutputStream(socket.getOutputStream());
			DataInputStream in = new DataInputStream(socket.getInputStream());
			out.writeUTF(userName + " joined the group.");
			out.flush();
			System.out.println("\nWelcome to the group " + userName + "!");
			Thread retrieve = new Thread() {
				public void run() {
					while (true) {
						try {
							if (in.available() > 1)
								System.out.print("\n" + in.readUTF());
						} catch (IOException ioe2) {

						}

					}
				}
			};
			retrieve.start();
			while (true) {
				System.out.print("\nEnter: ");
				message = scan.next();
				out.writeUTF(userName + " --- " + message);
				out.flush();
			}
		} catch (IOException ioe) {
			System.out.println("Couldn't Connect");
		}
	}
}
