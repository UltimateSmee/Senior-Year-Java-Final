package GROUP;

import java.io.IOException;
import java.util.Scanner;

public class Start {

	private static int port;
	private static String GROUP_NAME;
	private static int GROUP_SIZE = 5;
	private static String[] Alpha = { "", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o",
			"p", "q", "u", "r", "s", "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "4", "5", "6", "7", "8", "9",
			" " };
	private static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.print("Only numbers and letters will be accepted." + "\nOther characters will be deleted."
				+ "\nGroup Name: ");
		GROUP_NAME = scan.nextLine();

		try {
			Thread t = new Server(getPort(GROUP_NAME), 5);
			t.start();
		} catch (IOException ioe) {
			System.out.println(
					"Uh oh. It looks like that group was already made." + "\nDo you want to join that group? (y/n)");
			String c = scan.next();
			if (c.toLowerCase().equals("y")) {
				Client client = new Client(GROUP_NAME, port);
				client.joinServer();
			} else {
				main(null);
			}
		} finally {
			System.out.println("Congratualations you made the group " + GROUP_NAME);
			Client client = new Client(GROUP_NAME, port);
			client.joinServer();
		}
	}

	public static int getPort(String GROUP_NAME) {
		for (int i = 0; i < GROUP_NAME.length(); i++) {
			for (int p = 1; p < 38; p++) {
				if (Alpha[p].equals(GROUP_NAME.substring(i, i + 1).toLowerCase()))
					port += Math.abs((p - (4 * p)) * (p + p));
				// else
				// Start.GROUP_NAME = GROUP_NAME.replace(GROUP_NAME.substring(i,
				// i+1), "");
				if (port >= 65540)
					port -= p * p * p;
			}
		}
		return port;
	}
}
